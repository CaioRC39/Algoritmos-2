public interface Notificacao {
    // Métodos
    String enviar(String mensagem);

    void configurar(String destinatario);
}
